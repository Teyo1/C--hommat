
Verolaskuri on yksinkertainen konsolipohjainen ohjelma, joka laskee verot vuositulojen perusteella. Ohjelma kysyy käyttäjältä vuositulot ja veroprosentin, ja laskee niiden perusteella maksettavat verot. Lisäksi ohjelma tarjoaa mahdollisuuden tallentaa laskutiedot tekstitiedostoon.


1.	Ohjelma käynnistyy ja tervehtii käyttäjää.

2.	Syötä vuositulosi, kun ohjelma pyytää sitä. Syöte tulee olla desimaaliluku.

3.	Jos vuositulos on pienempi tai yhtä suuri kuin 0, ohjelma ilmoittaa, että teit tappiota.

4.	Muussa tapauksessa syötä veroprosentti, kun ohjelma pyytää sitä. Syöte tulee olla desimaaliluku.

5.	Ohjelma laskee verot ja näyttää ne sekä sen jälkeen jäävän summan.

6.	Ohjelma kysyy, haluatko tallentaa laskutiedot tiedostoon. Vastaa "kyllä" tai "ei".
	•	Jos vastaat "kyllä", ohjelma pyytää tiedoston nimeä ja tallentaa laskutiedot annettuun tiedostoon.
	•	Jos vastaat "ei", laskutietoja ei tallenneta.

7.	Ohjelma kysyy, haluatko sammuttaa laskurin. Vastaa "kyllä" tai "ei".
	•	Jos vastaat "kyllä", ohjelma tulostaa sulkemisajan ja lopettaa suorituksen.
	•	Jos vastaat "ei", ohjelma jatkaa toistamista alusta.

8.	Jos et sammuttanut laskuria, ohjelma näyttää ilmoituksen siitä, että laskuri sammuu automaattisesti 10 sekunnin kuluttua.

9.	Ohjelma odottaa 10 sekuntia, jonka jälkeen se sammuu.
